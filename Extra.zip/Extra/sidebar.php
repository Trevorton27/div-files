<?php if ( extra_get_sidebar_class() ) { ?>
<div class="et_pb_extra_column_sidebar">
	<?php dynamic_sidebar( extra_sidebar() ); ?>
</div>
<?php }
