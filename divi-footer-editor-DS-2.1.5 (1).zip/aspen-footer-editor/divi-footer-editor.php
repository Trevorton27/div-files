<?php
/*
Plugin Name: Aspen Footer Editor
Plugin URI: https://aspengrovestudios.com/
Description: An easy way to add or edit Footer Credit Text on Divi & Extra sites.
Version: 2.1.5
Author: Aspen Grove Studios
Author URI: https://aspengrovestudios.com/
License: GPL
*/
define('AGS_AFE_VERSION', '2.1.5');

require dirname(__FILE__).'/updater/updater.php';
require plugin_dir_path( __FILE__ ) . 'includes/functions.php';

function ags_afe_add_basic_js() {
	wp_register_script( 'custom-script', plugins_url( '/js/call.js', __FILE__ ), '', '1.1', true );
	wp_enqueue_script( 'custom-script' );
}
add_action( 'wp_enqueue_scripts', 'ags_afe_add_basic_js' );

function ags_afe_custom_css() {
	 wp_register_style( 'disable_divi_footer_css', plugins_url('css/custom.css', __FILE__ ),'','1.1', '' );
	 wp_enqueue_style( 'disable_divi_footer_css' );
}
add_action( 'wp_enqueue_scripts', 'ags_afe_custom_css' );
function ags_afe_load_wp_admin_style() {
        wp_register_style( 'wp_admin_css', plugins_url('css/admin.css', __FILE__ ),'','1.1', ''  );
        wp_enqueue_style( 'wp_admin_css' );
}
add_action( 'admin_enqueue_scripts', 'ags_afe_load_wp_admin_style' );

// Add settings link on plugin page
function ags_afe_settings_link($links) { 
  $settings_link = '<a href="admin.php?page=aspen-footer-editor">Settings</a>'; 
  array_unshift($links, $settings_link); 
  return $links; 
}
 
$plugin = plugin_basename(__FILE__); 
add_filter("plugin_action_links_$plugin", 'ags_afe_settings_link' );

function ags_afe_submenu_page() {
(AGS_AFE_has_license_key() ?
show_divi_footer_editor_page() :
AGS_AFE_activate_page());
}
 