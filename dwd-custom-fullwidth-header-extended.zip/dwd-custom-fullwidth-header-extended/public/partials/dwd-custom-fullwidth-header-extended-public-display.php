<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       dwd-custom-fullwidth-header-extended
 * @since      1.0.0
 *
 * @package    Dwd_Custom_Fullwidth_Header_Extended
 * @subpackage Dwd_Custom_Fullwidth_Header_Extended/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
