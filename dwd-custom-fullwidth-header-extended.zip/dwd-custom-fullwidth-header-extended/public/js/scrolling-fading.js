(function($) {
    var fhetyping = $('.dwd-fwe.dwd-sm-fade.et_pb_typing_effect'),
        dwdscrolling = $('.dwd-fwe.dwd-sm-fade');
    $(dwdscrolling).each(function(index, value) {
        var scrollMagicController = new ScrollMagic.Controller(),
            $this = $(this),
            $thisection = this,
            logo = $('.et_pb_fullwidth_logo_image', value),
            title = $('.et_pb_module_header', value),
            fancyline = $('hr', value),
            sub = $('.et_pb_fullwidth_header_subhead', value),
            text = $('.et_pb_header_content', value),
            btn = $('a', value),
            headerimg = $('.header-image', value);
        if (!$this.hasClass("dwd-slicey-blury")) {
            var tl = new TimelineMax({ pause: true });
            tl.add("start") // add timeline label
                .fromTo(logo, 0.500, { y: '30px', opacity: 0 }, { y: 0, opacity: 1, ease: Power2.EaseInOut }, "start")
                .fromTo(title, 0.500, { y: '40px', opacity: 0 }, { y: 0, opacity: 1, ease: Power2.EaseInOut }, "start")
                .fromTo(fancyline, 0.500, { y: '41px', opacity: 0 }, { y: 0, opacity: 1, ease: Power2.EaseInOut }, "start")
                .fromTo(sub, 0.500, { y: '45px', opacity: 0 }, { y: 0, opacity: 1, ease: Power2.EaseInOut }, "start")
                .fromTo(text, 0.500, { y: '60px', opacity: 0 }, { y: 0, opacity: 1, ease: Power2.EaseInOut }, "start")
                .fromTo(btn, 0.500, { y: '80px', opacity: 0 }, { y: 0, opacity: 1, ease: Power2.EaseInOut }, "start")
                .fromTo(headerimg, 0.500, { y: '80px', opacity: 0 }, { y: 0, opacity: 1, ease: Power2.EaseInOut }, "start")
            // Create the Scene and trigger when visible
            var scene = new ScrollMagic.Scene({
                    triggerElement: $thisection,
                    offset: 150 /* offset the trigger Npx below scene's top */
                })
                .on('enter', function() {
                    if ($('.dwd-fwe.dwd-sm-fade').hasClass('et_pb_typing_effect')) {
                        var $textforscroll = $(".dwd-typed", value).text(),
                            typingspeed = $(".et_pb_header_description", value).data('typing-speed'),
                            startdelay = $(".et_pb_header_description", value).data('typing-delay'),
                            backdelay = $(".et_pb_header_description", value).data('typing-backdelay'),
                            typingloop = $(".et_pb_header_description", value).data('typing-loop'),
                            typingelement = $(".dwd-typing", value),
                            arr = $textforscroll.split('|');
                        $(typingelement).typed({
                            strings: arr,
                            startDelay: startdelay,
                            loop: typingloop,
                            typeSpeed: typingspeed,
                            // timedelay before backspacing
                            backDelay: backdelay,
                            contentType: 'html',
                            callback: function() {
                                if ($(".et_pb_header_description", value).attr('data-typing-loop') === 'false' && $(".et_pb_header_description", value).attr('data-typing-cursor') === 'true') {
                                    $(".typed-cursor", value).hide();
                                }
                            }
                        });

                    }
                })
                .on('leave', function() {
                    if ($('.dwd-fwe.dwd-sm-fade').hasClass('et_pb_typing_effect')) {
                        var typingelement = $(".dwd-fwe.dwd-sm-fade .dwd-typing", value);
                        $(typingelement).typed({
                            strings: [""]
                        });
                    }
                })
                .setTween(tl)
                .addTo(scrollMagicController);
        }
    });
})(jQuery);