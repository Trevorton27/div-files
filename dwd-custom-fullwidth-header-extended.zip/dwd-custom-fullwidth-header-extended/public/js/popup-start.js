jQuery(document).ready(function($) {
    $("a.dwd-popup-content").magnificPopup({
        type: 'inline',
        // Delay in milliseconds before popup is removed
        removalDelay: 700,
        fixedContentPos: true,
        closeOnBgClick: true,
        midClick: true, // Allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source in href.
        mainClass: 'dwd-custom-popup-one-styles', // this class is for CSS animation below
        prependTo: '#page-container',

        callbacks: {
            open: function() {
                var selector = this.content.selector;
                console.log(this);
                if ($(selector).hasClass('dwd-popup-fullscreen')) {
                    console.log('yes yes');
                    //this.st.mainClass = this.st.mainClasss + ' dwd-popup-full animated';
                    this.container.addClass('dwd-popup-full');

                }
            },
            beforeClose: function() {
                var selector = this.content.selector;
                var dataout = $(selector).data('dwd-animation-out');
                this.content.addClass(dataout);
            },
            close: function() {
                var selector = this.content.selector;
                var dataout = $(selector).data('dwd-animation-out');
                this.content.removeClass(dataout);
            }
        }
    });
    $("a.dwd-popup-content").click(function() {
        $(".mfp-bg").addClass($(".dwd-fw-popup").attr('id'));
    });

});