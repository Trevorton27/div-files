<?php

/**
 * Fired during plugin activation
 *
 * @link       dwd-custom-fullwidth-header-extended
 * @since      1.0.0
 *
 * @package    Dwd_Custom_Fullwidth_Header_Extended
 * @subpackage Dwd_Custom_Fullwidth_Header_Extended/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Dwd_Custom_Fullwidth_Header_Extended
 * @subpackage Dwd_Custom_Fullwidth_Header_Extended/includes
 * @author     Divi Web Design <hello@diviwebdesign.com>
 */
class Dwd_Custom_Fullwidth_Header_Extended_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
