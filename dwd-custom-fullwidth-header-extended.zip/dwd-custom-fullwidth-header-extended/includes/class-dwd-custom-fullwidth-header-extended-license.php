<?php
// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
if ( ! defined( 'DWD_EMP_LICENSE_SERVER_URL' ) ) {
    define( 'DWD_EMP_LICENSE_SERVER_URL', 'https://elegantmarketplace.com' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file
}
// the name of your product. This should match the download name in EDD exactly
if ( ! defined( 'DWD_EMP_FHE_ITEM_REFERENCE' ) ) {
    define( 'DWD_EMP_FHE_ITEM_REFERENCE', 'Fullwidth Header Extended' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file
}
// This is a value that will be recorded in the license manager data so you can identify licenses for this item/product.
if ( ! defined( 'DWD_EMP_AIO_ITEM_REFERENCE' ) ) {
    define('DWD_EMP_AIO_ITEM_REFERENCE', 'Perky Animate Module'); //Rename this constant name so it is specific to your plugin or theme.
}
// This is a value that will be recorded in the license manager data so you can identify licenses for this item/product.
if ( ! defined( 'DWD_EMP_MAP_ITEM_REFERENCE' ) ) {
    define('DWD_EMP_MAP_ITEM_REFERENCE', 'Divi Map Extended Module'); //Rename this constant name so it is specific to your plugin or theme.
}

if( !class_exists( 'DWD_EMP_Plugin_Updater' ) ) {
    // load our custom updater
    include( plugin_dir_path( dirname( __FILE__ ) ) . 'admin/core/DWD_Plugin_Updater.php' );
}

function dwd_fhe_check_plugin_updater() {
    // retrieve our license key from the DB
    $license_key = trim( get_option( 'fhe_license_key' ) );
    // setup the updater
    $edd_updater = new DWD_EMP_Plugin_Updater( DWD_EMP_LICENSE_SERVER_URL, __FILE__, array(
            'version'   => '2.1.7',               // current version number
            'license'   => $license_key,        // license key (used get_option above to retrieve from DB)
            'item_name' => DWD_EMP_FHE_ITEM_REFERENCE,  // name of this plugin
            'author'    => 'Divi Web Design',  // author of this plugin
            'beta'      => false
        )
    );

}
add_action( 'admin_init', 'dwd_fhe_check_plugin_updater', 0 );

/************************************
* the code below is just a standard
* options page. Substitute with
* your own.
*************************************/

if ( ! function_exists( 'dwd_emp_plugin_top_menu' ) ) :
        function dwd_emp_plugin_top_menu() {
                add_submenu_page( 'options-general.php', 'Divi Extended', 'Divi Extended (EMP)', 'manage_options', 'dwd-emp-management-page', 'dwd_emp_management_page' );
        }
endif;
add_action('admin_menu', 'dwd_emp_plugin_top_menu');

if ( ! function_exists( 'dwd_emp_management_page' ) ) :
function dwd_emp_management_page() {
    $license = get_option( 'fhe_license_key' );
    $status  = get_option( 'fhe_license_status' );
    $license_a = get_option( 'aio_license_key' );
    $status_a  = get_option( 'aio_license_status' );
    $license_m = get_option( 'map_license_key' );
    $status_m  = get_option( 'map_license_status' );
    ?>
    <div class="wrap">
        <h2><?php _e('Divi Web Design License Page Settings'); ?></h2>
        <p>Copy and paste your license key into the input field and click on Save Changes first. After that, Click on Activate License.</p>
        <?php
            /**FHE**/
            if ( is_plugin_active('dwd-custom-fullwidth-header-extended/load-fullwidth-header-extended.php') ) { ?>
                <form method="post" action="options.php">

                    <?php settings_fields('dwd_fhe_license'); ?>

                    <table class="form-table">
                        <tbody>
                            <tr valign="top">
                                <th scope="row" valign="top">
                                    <?php _e('Fullwidth Header Extended License Key'); ?>
                                </th>
                                <td>
                                    <input id="fhe_license_key" name="fhe_license_key" type="text" class="regular-text" value="<?php esc_attr_e( $license ); ?>" />
                                    <label class="description" for="fhe_license_key"><?php _e('Enter your license key'); ?></label>
                                </td>
                            </tr>
                            <?php if( false !== $license ) { ?>
                                <tr valign="top">
                                    <th scope="row" valign="top">
                                        <?php _e('Activate License'); ?>
                                    </th>
                                    <td>
                                        <?php if( $status !== false && $status == 'valid' ) { ?>
                                            <span style="color:green;"><?php _e('active'); ?></span>
                                            <?php wp_nonce_field( 'dwd_fhe_nonce', 'dwd_fhe_nonce' ); ?>
                                            <input type="submit" class="button-secondary" name="dwd_fhe_license_deactivate" value="<?php _e('Deactivate License'); ?>"/>
                                        <?php } else {
                                            wp_nonce_field( 'dwd_fhe_nonce', 'dwd_fhe_nonce' ); ?>
                                            <input type="submit" class="button-secondary" name="dwd_fhe_license_activate" value="<?php _e('Activate License'); ?>"/>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <?php submit_button(); ?>

                </form>
        <?php } /** End FHE**/
            /** AIO **/
            if ( is_plugin_active('dwd-aio-module-extended-plugin/load_aio_module.php') ) { ?>
                <form method="post" action="options.php">

                    <?php settings_fields('dwd_aio_license'); ?>

                    <table class="form-table">
                        <tbody>
                            <tr valign="top">
                                <th scope="row" valign="top">
                                    <?php _e('All-in-One Extended Module License Key'); ?>
                                </th>
                                <td>
                                    <input id="aio_license_key" name="aio_license_key" type="text" class="regular-text" value="<?php esc_attr_e( $license_a ); ?>" />
                                    <label class="description" for="aio_license_key"><?php _e('Enter your license key'); ?></label>
                                </td>
                            </tr>
                            <?php if( false !== $license_a ) { ?>
                                <tr valign="top">
                                    <th scope="row" valign="top">
                                        <?php _e('Activate License'); ?>
                                    </th>
                                    <td>
                                        <?php if( $status_a !== false && $status_a == 'valid' ) { ?>
                                            <span style="color:green;"><?php _e('active'); ?></span>
                                            <?php wp_nonce_field( 'dwd_aio_nonce', 'dwd_aio_nonce' ); ?>
                                            <input type="submit" class="button-secondary" name="dwd_aio_license_deactivate" value="<?php _e('Deactivate License'); ?>"/>
                                        <?php } else {
                                            wp_nonce_field( 'dwd_aio_nonce', 'dwd_aio_nonce' ); ?>
                                            <input type="submit" class="button-secondary" name="dwd_aio_license_activate" value="<?php _e('Activate License'); ?>"/>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <?php submit_button(); ?>

                </form>
        <?php } /** End AIO**/
        /**MAP**/
            if ( is_plugin_active('dwd-map-extended/load_custom_map_module.php') ) { ?>

                <form method="post" action="options.php">

                    <?php settings_fields('dwd_map_license'); ?>

                    <table class="form-table">
                        <tbody>
                            <tr valign="top">
                                <th scope="row" valign="top">
                                    <?php _e('Divi Map Extended Extended License Key'); ?>
                                </th>
                                <td>
                                    <input id="map_license_key" name="map_license_key" type="text" class="regular-text" value="<?php esc_attr_e( $license_m ); ?>" />
                                    <label class="description" for="map_license_key"><?php _e('Enter your license key'); ?></label>
                                </td>
                            </tr>
                            <?php if( false !== $license_m ) { ?>
                                <tr valign="top">
                                    <th scope="row" valign="top">
                                        <?php _e('Activate License'); ?>
                                    </th>
                                    <td>
                                        <?php if( $status_m !== false && $status_m == 'valid' ) { ?>
                                            <span style="color:green;"><?php _e('active'); ?></span>
                                            <?php wp_nonce_field( 'dwd_map_nonce', 'dwd_map_nonce' ); ?>
                                            <input type="submit" class="button-secondary" name="dwd_map_license_deactivate" value="<?php _e('Deactivate License'); ?>"/>
                                        <?php } else {
                                            wp_nonce_field( 'dwd_map_nonce', 'dwd_map_nonce' ); ?>
                                            <input type="submit" class="button-secondary" name="dwd_map_license_activate" value="<?php _e('Activate License'); ?>"/>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <?php submit_button(); ?>
                </form>
        <?php } /** End MAP**/ ?>
    </div><!--end ofwrap -->
<?php
}
endif;

if ( ! function_exists( 'dwd_fhe_register_option' ) ) :
function dwd_fhe_register_option() {
    // creates our settings in the options table
    register_setting('dwd_fhe_license', 'fhe_license_key', 'dwd_fhe_sanitize_license' );
}
endif;

add_action('admin_init', 'dwd_fhe_register_option');

if ( ! function_exists( 'dwd_fhe_sanitize_license' ) ) :
function dwd_fhe_sanitize_license( $new ) {
    $old = get_option( 'fhe_license_key' );
    if( $old && $old != $new ) {
        delete_option( 'fhe_license_status' ); // new license has been entered, so must reactivate
    }
    return $new;
}
endif;


/************************************
* this illustrates how to activate
* a license key
*************************************/

function dwd_fhe_activate_license() {

    // listen for our activate button to be clicked
    if( isset( $_POST['dwd_fhe_license_activate'] ) ) {

        // run a quick security check
        if( ! check_admin_referer( 'dwd_fhe_nonce', 'dwd_fhe_nonce' ) )
            return; // get out if we didn't click the Activate button

        // retrieve the license from the database
        $license = trim( get_option( 'fhe_license_key' ) );


        // data to send in our API request
        $api_params = array(
            'edd_action' => 'activate_license',
            'license'    => $license,
            'item_name'  => urlencode( DWD_EMP_FHE_ITEM_REFERENCE ), // the name of our product in EDD
            'url'        => home_url()
        );

        // Call the custom API.
        $response = wp_remote_post( DWD_EMP_LICENSE_SERVER_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

        // make sure the response came back okay
        if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

            if ( is_wp_error( $response ) ) {
                $message = $response->get_error_message();
            } else {
                $message = __( 'An error occurred, please try again.' );
            }

        } else {

            $license_data = json_decode( wp_remote_retrieve_body( $response ) );

            if ( false === $license_data->success ) {

                switch( $license_data->error ) {

                    case 'expired' :

                        $message = sprintf(
                            __( 'Your license key expired on %s.' ),
                            date_i18n( get_option( 'date_format' ), strtotime( $license_data->expires, current_time( 'timestamp' ) ) )
                        );
                        break;

                    case 'revoked' :

                        $message = __( 'Your license key has been disabled.' );
                        break;

                    case 'missing' :

                        $message = __( 'Invalid license.' );
                        break;

                    case 'invalid' :
                    case 'site_inactive' :

                        $message = __( 'Your license is not active for this URL.' );
                        break;

                    case 'item_name_mismatch' :

                        $message = sprintf( __( 'This appears to be an invalid license key for %s.' ), DWD_EMP_FHE_ITEM_REFERENCE );
                        break;

                    case 'no_activations_left':

                        $message = __( 'Your license key has reached its activation limit.' );
                        break;

                    default :

                        $message = __( 'An error occurred, please try again.' );
                        break;
                }

            }

        }

        // Check if anything passed on a message constituting a failure
        if ( ! empty( $message ) ) {
            $base_url = admin_url( 'options-general.php?page=dwd-emp-management-page' );
            $redirect = add_query_arg( array( 'sl_activation' => 'false', 'message' => urlencode( $message ) ), $base_url );

            wp_redirect( $redirect );
            exit();
        }

        // $license_data->license will be either "valid" or "invalid"

        update_option( 'fhe_license_status', $license_data->license );
        wp_redirect( admin_url( 'options-general.php?page=dwd-emp-management-page' ) );
        exit();
    }
}
add_action('admin_init', 'dwd_fhe_activate_license');


/***********************************************
* Illustrates how to deactivate a license key.
* This will decrease the site count
***********************************************/

function dwd_fhe_deactivate_license() {

    // listen for our activate button to be clicked
    if( isset( $_POST['dwd_fhe_license_deactivate'] ) ) {

        // run a quick security check
        if( ! check_admin_referer( 'dwd_fhe_nonce', 'dwd_fhe_nonce' ) )
            return; // get out if we didn't click the Activate button

        // retrieve the license from the database
        $license = trim( get_option( 'fhe_license_key' ) );


        // data to send in our API request
        $api_params = array(
            'edd_action' => 'deactivate_license',
            'license'    => $license,
            'item_name'  => urlencode( DWD_EMP_FHE_ITEM_REFERENCE ), // the name of our product in EDD
            'url'        => home_url()
        );

        // Call the custom API.
        $response = wp_remote_post( DWD_EMP_LICENSE_SERVER_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

        // make sure the response came back okay
        if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

            if ( is_wp_error( $response ) ) {
                $message = $response->get_error_message();
            } else {
                $message = __( 'An error occurred, please try again.' );
            }

            $base_url = admin_url( 'options-general.php?page=dwd-emp-management-page' );
            $redirect = add_query_arg( array( 'sl_activation' => 'false', 'message' => urlencode( $message ) ), $base_url );

            wp_redirect( $redirect );
            exit();
        }

        // decode the license data
        $license_data = json_decode( wp_remote_retrieve_body( $response ) );

        // $license_data->license will be either "deactivated" or "failed"
        if( $license_data->license == 'deactivated' ) {
            delete_option( 'fhe_license_status' );
        }

        wp_redirect( admin_url( 'options-general.php?page=dwd-emp-management-page' ) );
        exit();

    }
}
add_action('admin_init', 'dwd_fhe_deactivate_license');


/************************************
* this illustrates how to check if
* a license key is still valid
* the updater does this for you,
* so this is only needed if you
* want to do something custom
*************************************/

function dwd_fhe_check_license() {

    global $wp_version;

    $license = trim( get_option( 'fhe_license_key' ) );

    $api_params = array(
        'edd_action' => 'check_license',
        'license' => $license,
        'item_name' => urlencode( DWD_EMP_FHE_ITEM_REFERENCE ),
        'url'       => home_url()
    );

    // Call the custom API.
    $response = wp_remote_post( DWD_EMP_LICENSE_SERVER_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

    if ( is_wp_error( $response ) )
        return false;

    $license_data = json_decode( wp_remote_retrieve_body( $response ) );

    if( $license_data->license == 'valid' ) {
        echo 'valid'; exit;
        // this license is still valid
    } else {
        echo 'invalid'; exit;
        // this license is no longer valid
    }
}

/**
 * This is a means of catching errors from the activation method above and displaying it to the customer
 */
function dwd_fhe_admin_notices() {
    if ( isset( $_GET['sl_activation'] ) && ! empty( $_GET['message'] ) ) {

        switch( $_GET['sl_activation'] ) {

            case 'false':
                $message = urldecode( $_GET['message'] );
                ?>
                <div class="error">
                    <p><?php echo $message; ?></p>
                </div>
                <?php
                break;

            case 'true':
            default:
                // Developers can put a custom success message here for when activation is successful if they way.
                break;

        }
    }
}
add_action( 'admin_notices', 'dwd_fhe_admin_notices' );
$license_key = trim( get_option( 'fhe_license_key' ) );

function dwd_fhe_emp_license_notice() {
    if ( ! FHEPAnD::is_admin_notice_active( 'fhe-disable-done-notice-forever' ) ) {
        return;
    }
    $class = 'notice notice-info is-dismissible';
    $message = __( 'Please enter your Fullwidth Header Extended Module plugin license key to get regular update and support by Navigating to Settings -> Divi Extended. You were given a license key when you purchased this item.', 'dwd-fhe' );

    printf( '<div data-dismissible="fhe-disable-done-notice-forever" class="%1$s"><p>%2$s</p></div>', $class, $message );
}

if ( empty( $license_key ) ) {
    add_action( 'admin_notices', 'dwd_fhe_emp_license_notice' );
    add_action( 'admin_init', array( 'FHEPAnD', 'init' ) );
}
?>