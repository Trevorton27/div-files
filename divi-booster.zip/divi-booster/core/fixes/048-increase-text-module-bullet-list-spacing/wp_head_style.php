<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_text ul, 
.et_pb_text ol,
.et_divi_builder #et_builder_outer_content .et_pb_module.et_pb_text ul, 
.et_divi_builder #et_builder_outer_content .et_pb_module.et_pb_text ol { 
	margin: 30px; 
}
.et_divi_builder #et_builder_outer_content .et_pb_module.et_pb_text li,
.et_pb_text li { 
	margin-top: 16px; 
}