<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_fullwidth_portfolio .et_pb_portfolio_image img { 
    max-width:100% !important; 
    min-width: 0 !important; 
    width: auto !important; 
    max-height: 100% !important; 
    min-height: 0 !important; 
    height: auto !important; 
    position: relative;
    top: 50%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
}
.et_pb_fullwidth_portfolio .et_pb_portfolio_image { 
    text-align:center !important;
}
