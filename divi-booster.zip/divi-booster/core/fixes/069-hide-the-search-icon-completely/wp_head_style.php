<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#et_top_search, .et_header_style_centered div#et_top_search { display:none !important; }