<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
@media only screen and ( min-width: 768px ) {
	#top-header .et-social-icons { float:right !important; }
	#top-header #et-info { width: 100%; }
}




