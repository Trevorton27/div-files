<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
body.single article.has-post-thumbnail > img:nth-of-type(1),
body.single article.has-post-thumbnail .et_post_meta_wrapper > img:nth-of-type(1) { 
	position:absolute;
	left:0;
	top:0; 
}