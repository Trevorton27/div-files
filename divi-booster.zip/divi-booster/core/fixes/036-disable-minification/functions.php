<?php 
if (!defined('ABSPATH')) { exit(); } // No direct access

$this->minifiedcss = false; ?>