<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
jQuery(function($){ $('.et-social-icon a').attr('target', '_blank'); });