<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#slb_viewer_slb_default { z-index: 100000 !important; }