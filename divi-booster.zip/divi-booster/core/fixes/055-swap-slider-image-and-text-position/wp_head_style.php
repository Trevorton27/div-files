<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_slide_description { float:left !important; padding-left:100px !important }
.et_pb_slide_image { right:100px; }