<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
@media only screen and (min-width: 768px) {
	#et-info { float:right !important }
}